import React, { useEffect } from 'react';

interface LoadingProps {
  onComplete: () => void;
}

export const Loading: React.FC<LoadingProps> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 5000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-kandu-950 z-50 fixed inset-0">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute inset-0 border-t-4 border-zinc-200 rounded-full animate-spin"></div>
        <div className="absolute inset-2 border-t-4 border-zinc-500 rounded-full animate-spin [animation-duration:1.5s]"></div>
        <div className="absolute inset-4 border-t-4 border-zinc-700 rounded-full animate-spin [animation-duration:2s]"></div>
      </div>
      <h2 className="text-zinc-200 text-xl font-light tracking-[0.2em] animate-pulse">
        MEMUAT K4NDU AI...
      </h2>
      <p className="text-kandu-500 text-sm mt-2">Menghubungkan ke neural network</p>
    </div>
  );
};