import React from 'react';
import { Bot } from 'lucide-react';

export const ThinkingBubble: React.FC = () => {
  return (
    <div className="flex w-full mb-6 justify-start">
      <div className="flex flex-row items-end gap-2">
        <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-zinc-200 animate-pulse">
          <Bot size={16} className="text-zinc-900" />
        </div>
        <div className="bg-kandu-200 text-zinc-900 px-5 py-4 rounded-2xl rounded-bl-none shadow-md flex items-center gap-1.5 h-12">
           <div className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
           <div className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
           <div className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce"></div>
        </div>
      </div>
    </div>
  );
};