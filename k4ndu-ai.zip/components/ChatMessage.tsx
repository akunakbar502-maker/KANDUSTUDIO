import React, { useRef } from 'react';
import { Message, Role } from '../types';
import { User, Bot, Play, Pause } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
  isPlaying: boolean;
  onPlay: (message: Message) => void;
  onPause: () => void;
  onDelete: (id: string) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isPlaying, onPlay, onPause, onDelete }) => {
  const isUser = message.role === Role.USER;
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const togglePlayback = () => {
    if (isPlaying) {
        onPause();
    } else {
        onPlay(message);
    }
  };

  // --- Long Press Logic ---
  const startLongPress = () => {
    longPressTimer.current = setTimeout(() => {
        if (window.confirm("Hapus pesan ini?")) {
            onDelete(message.id);
        }
    }, 800);
  };

  const cancelLongPress = () => {
    if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
    }
  };

  // If it's voice only from AI, we hide the text
  const showText = !message.isVoiceOnly;

  return (
    <div 
        className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'} select-none`}
        onMouseDown={startLongPress}
        onMouseUp={cancelLongPress}
        onMouseLeave={cancelLongPress}
        onTouchStart={startLongPress}
        onTouchEnd={cancelLongPress}
    >
      <div className={`flex max-w-[85%] md:max-w-[70%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-end gap-2 group`}>
        
        {/* Avatar with Animation */}
        <div className={`
            flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center 
            ${isUser ? 'bg-zinc-700' : 'bg-zinc-200'}
            ${!isUser && 'shadow-[0_0_15px_rgba(255,255,255,0.3)] animate-[pulse_4s_cubic-bezier(0.4,0,0.6,1)_infinite]'}
        `}>
          {isUser ? <User size={16} className="text-zinc-300" /> : <Bot size={16} className="text-zinc-900" />}
        </div>

        {/* Bubble */}
        <div className={`
          relative px-5 py-3 rounded-2xl shadow-md overflow-hidden transition-all duration-200
          ${isUser 
            ? 'bg-zinc-800 text-zinc-100 rounded-br-none border border-zinc-700 active:scale-95' 
            : 'bg-kandu-200 text-zinc-900 rounded-bl-none active:scale-95'}
        `}>
          
          {/* Image Attachment */}
          {message.imageUrl && (
            <div className="mb-3 rounded-lg overflow-hidden border border-black/10">
              <img src={message.imageUrl} alt="Uploaded content" className="w-full h-auto max-h-64 object-cover" />
            </div>
          )}

          {/* Audio Message UI */}
          {(message.isVoiceResponse || (message.audioUrl && isUser)) && (
            <div className={`flex items-center gap-3 ${showText ? 'mb-2' : ''} p-2 rounded-lg ${isUser ? 'bg-zinc-900/50' : 'bg-white/50'}`}>
               <button 
                onClick={(e) => {
                    e.stopPropagation(); // Prevent long press bubbling
                    togglePlayback();
                }}
                className={`p-3 rounded-full flex-shrink-0 transition-all active:scale-90 ${
                    isUser 
                    ? isPlaying ? 'bg-zinc-600 text-white' : 'bg-zinc-700 hover:bg-zinc-600' 
                    : isPlaying ? 'bg-zinc-700 text-white' : 'bg-zinc-800 hover:bg-zinc-700 text-white'
                }`}
               >
                 {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
               </button>
               
               {/* Audio Visualization / Waveform Simulation */}
               <div className="flex items-center gap-1 h-8">
                  {[...Array(10)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-1 rounded-full transition-all duration-300 ${isUser ? 'bg-zinc-500' : 'bg-zinc-800'}`}
                        style={{ 
                            height: isPlaying ? `${Math.random() * 60 + 20}%` : '4px',
                            animation: isPlaying ? `pulse 0.8s ease-in-out infinite` : 'none',
                            animationDelay: `${i * 0.1}s` 
                        }}
                      ></div>
                  ))}
               </div>
            </div>
          )}

          {/* Text Content - Hidden if Voice Only Mode */}
          {showText && (
              <p className={`whitespace-pre-wrap text-sm md:text-base leading-relaxed ${isUser ? 'text-zinc-200' : 'text-zinc-800'}`}>
                {message.text}
              </p>
          )}
          
          <span className={`text-[10px] absolute bottom-1 ${isUser ? 'left-2 text-zinc-500' : 'right-2 text-zinc-500'}`}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </div>
  );
};