import React, { useState } from 'react';
import { LOGIN_USER, LOGIN_PASS } from '../constants';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === LOGIN_USER && password === LOGIN_PASS) {
      onLogin();
    } else {
      setError('Akses ditolak. Identitas tidak dikenali.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-kandu-950 px-4">
      <div className="w-full max-w-md p-8 bg-kandu-900 rounded-2xl border border-kandu-800 shadow-2xl">
        <div className="flex justify-center mb-8">
           <div className="w-16 h-16 bg-zinc-200 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.1)]">
              <span className="text-kandu-950 font-bold text-2xl">K4</span>
           </div>
        </div>
        <h2 className="text-2xl font-semibold text-center text-zinc-200 mb-6 tracking-wide">
          LOGIN SISTEM
        </h2>
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-kandu-400 mb-2">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 bg-kandu-950 border border-kandu-700 rounded-xl text-zinc-200 focus:outline-none focus:ring-2 focus:ring-zinc-500 focus:border-transparent transition-all placeholder-kandu-600"
              placeholder="Masukkan username"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-kandu-400 mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-kandu-950 border border-kandu-700 rounded-xl text-zinc-200 focus:outline-none focus:ring-2 focus:ring-zinc-500 focus:border-transparent transition-all placeholder-kandu-600"
              placeholder="Masukkan password"
            />
          </div>
          {error && (
            <div className="text-red-400 text-sm text-center bg-red-900/20 py-2 rounded-lg border border-red-900/30">
              {error}
            </div>
          )}
          <button
            type="submit"
            className="w-full py-3 bg-zinc-200 text-kandu-950 font-bold rounded-xl hover:bg-white hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 shadow-lg"
          >
            MASUK
          </button>
        </form>
      </div>
    </div>
  );
};