import React, { useState, useEffect, useRef } from 'react';
import { Login } from './components/Login';
import { Loading } from './components/Loading';
import { ChatMessage } from './components/ChatMessage';
import { ThinkingBubble } from './components/ThinkingBubble'; 
import { Message, Role, UserProfile } from './types';
import { Mic, Send, Image as ImageIcon, Trash2, LogOut, Moon, Sun } from 'lucide-react';
import { sendMessageToGemini, generateSpeech } from './services/geminiService';
import { blobToBase64, playPCMAudio } from './utils/audioUtils';
import { APP_NAME } from './constants';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isThinking, setIsThinking] = useState(false); 
  const [isDarkMode, setIsDarkMode] = useState(true);
  
  // App Logic State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [profileName, setProfileName] = useState('K4NDU User');
  
  // Audio Player State
  const [currentPlayingId, setCurrentPlayingId] = useState<string | null>(null);
  const audioControllerRef = useRef<{ stop: () => void } | null>(null);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initial Welcome Message
  useEffect(() => {
    if (isAuthenticated && !isLoading && messages.length === 0) {
      const welcomeMsg: Message = {
        id: 'init-1',
        role: Role.MODEL,
        text: "Hallo, saya adalah Kandu Ey Ay, kamu bisa awali percakapan kita dengan bertanya siapa yang membuat saya, atau awali dengan pertanyaan apapun itu.",
        timestamp: Date.now()
      };
      setMessages([welcomeMsg]);
    }
  }, [isAuthenticated, isLoading, messages.length]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  // Theme Toggle
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // --- Audio Control Logic ---
  
  const stopCurrentAudio = () => {
    if (audioControllerRef.current) {
        audioControllerRef.current.stop();
        audioControllerRef.current = null;
    }
    setCurrentPlayingId(null);
  };

  const handlePlayAudio = (message: Message) => {
    // 1. Stop anything currently playing
    stopCurrentAudio();
    
    // 2. Set as playing
    setCurrentPlayingId(message.id);

    // 3. Play based on type
    if (message.isVoiceResponse && message.audioUrl) {
        // AI PCM Audio
        const base64 = message.audioUrl.split(',')[1];
        const controller = playPCMAudio(base64, 24000, () => {
            setCurrentPlayingId(null);
        });
        audioControllerRef.current = controller;

    } else if (message.audioUrl) {
        // User Blob Audio
        const audio = new Audio(message.audioUrl);
        audio.play();
        audio.onended = () => {
            setCurrentPlayingId(null);
        };
        audio.onpause = () => {
             // Handle manual pause if needed, but for now we just treat pause as stop in UI
             if (audio.ended) setCurrentPlayingId(null);
        };
        
        audioControllerRef.current = {
            stop: () => {
                audio.pause();
                audio.currentTime = 0;
            }
        };
    }
  };


  // --- Handlers ---

  const handleLoginSuccess = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsAuthenticated(true);
      generateRandomUsername();
    }, 5000); 
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    stopCurrentAudio();
    setMessages([]);
    setInputText('');
  };

  const clearChat = () => {
    if (window.confirm("Hapus semua riwayat pesan?")) {
        stopCurrentAudio();
        setMessages([]);
        const welcomeMsg: Message = {
            id: Date.now().toString(),
            role: Role.MODEL,
            text: "Hallo, saya adalah Kandu Ey Ay, riwayat telah dihapus.",
            timestamp: Date.now()
        };
        setMessages([welcomeMsg]);
    }
  };

  const deleteMessage = (id: string) => {
    if (currentPlayingId === id) stopCurrentAudio();
    setMessages(prev => prev.filter(msg => msg.id !== id));
  };

  const generateRandomUsername = () => {
    const randomNum = Math.floor(Math.random() * 10000);
    setProfileName(`k4nd - ${randomNum}`);
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      text: inputText,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    await processGeminiResponse(inputText);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const base64 = await blobToBase64(file);
    const mimeType = file.type;
    const imageUrl = `data:${mimeType};base64,${base64}`;

    const userMsg: Message = {
        id: Date.now().toString(),
        role: Role.USER,
        text: "Mengirim gambar...",
        timestamp: Date.now(),
        imageUrl: imageUrl
    };
    
    setMessages(prev => [...prev, userMsg]);

    setIsThinking(true);
    const responseText = await sendMessageToGemini(
        messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
        "Analisis gambar ini.", 
        base64,
        mimeType
    );
    setIsThinking(false);

    const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.MODEL,
        text: responseText,
        timestamp: Date.now()
    };
    setMessages(prev => [...prev, botMsg]);
  };

  const startRecording = async () => {
    // If already recording, don't start again
    if (isRecording) return;
    
    // Stop any playing audio before recording
    stopCurrentAudio();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        // Prevent processing empty recordings (clicks without holding)
        if (chunks.length === 0) return;

        const audioBlob = new Blob(chunks, { type: 'audio/webm' });
        // Check size or duration roughly to avoid micro-clicks
        if (audioBlob.size < 1000) return; 

        const audioUrl = URL.createObjectURL(audioBlob);
        
        // 1. Add User Voice Message
        const userMsg: Message = {
            id: Date.now().toString(),
            role: Role.USER,
            text: "(Pesan Suara)",
            timestamp: Date.now(),
            audioUrl: audioUrl
        };
        setMessages(prev => [...prev, userMsg]);

        // 2. Transcribe & Process
        const base64Audio = await blobToBase64(audioBlob);
        
        setIsThinking(true);
        const responseText = await sendMessageToGemini(
             [], 
             "User sent an audio message. Listen to it and respond naturally. Keep it concise.",
             base64Audio,
             'audio/webm'
        );

        // 3. Generate Audio Response (TTS)
        const ttsAudioBase64 = await generateSpeech(responseText);
        setIsThinking(false);
        
        const botMsg: Message = {
            id: (Date.now() + 1).toString(),
            role: Role.MODEL,
            text: responseText, 
            timestamp: Date.now(),
            isVoiceResponse: true,
            isVoiceOnly: true, 
            audioUrl: ttsAudioBase64 ? `data:audio/pcm;base64,${ttsAudioBase64}` : undefined
        };

        setMessages(prev => [...prev, botMsg]);
        // REMOVED AUTO-PLAY as requested
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (err) {
      console.error("Mic error:", err);
      alert("Gagal mengakses mikrofon.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
      }
      setIsRecording(false);
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      setMediaRecorder(null);
    }
  };

  const processGeminiResponse = async (textInput: string) => {
    setIsThinking(true);
    // Limit history
    const history = messages.slice(-10).map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
    }));

    const responseText = await sendMessageToGemini(history, textInput);
    setIsThinking(false);

    const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.MODEL,
        text: responseText,
        timestamp: Date.now()
    };
    setMessages(prev => [...prev, botMsg]);
  };

  // --- Render ---

  if (!isAuthenticated) {
    return <Login onLogin={handleLoginSuccess} />;
  }

  if (isLoading) {
    return <Loading onComplete={() => {}} />;
  }

  return (
    <div className={`flex flex-col h-screen ${isDarkMode ? 'bg-kandu-950 text-zinc-100' : 'bg-kandu-100 text-zinc-900'} transition-colors duration-300 font-sans`}>
      
      {/* Header */}
      <header className={`flex items-center justify-between px-4 py-3 border-b ${isDarkMode ? 'bg-kandu-900 border-kandu-800' : 'bg-white border-kandu-200'} shadow-sm z-10`}>
        <div className="flex items-center gap-3 cursor-pointer" onClick={generateRandomUsername} title="Klik untuk ganti ID">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 flex items-center justify-center text-white font-bold border border-zinc-600 shadow-inner">
             K4
          </div>
          <div>
             <h1 className="font-semibold text-sm md:text-base">{APP_NAME}</h1>
             <p className={`text-xs ${isDarkMode ? 'text-zinc-400' : 'text-zinc-500'}`}>{profileName}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
            <button 
                onClick={() => setIsDarkMode(!isDarkMode)} 
                className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-zinc-800 text-zinc-400' : 'hover:bg-zinc-200 text-zinc-600'}`}
            >
                {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button 
                onClick={clearChat} 
                className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-zinc-800 text-red-400' : 'hover:bg-zinc-200 text-red-500'}`}
                title="Hapus Semua Pesan"
            >
                <Trash2 size={20} />
            </button>
            <button 
                onClick={handleLogout} 
                className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-zinc-800 text-zinc-400' : 'hover:bg-zinc-200 text-zinc-600'}`}
                title="Logout"
            >
                <LogOut size={20} />
            </button>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 no-scrollbar scroll-smooth">
        <div className="max-w-3xl mx-auto">
            {messages.map((msg) => (
                <ChatMessage 
                    key={msg.id} 
                    message={msg} 
                    onDelete={deleteMessage}
                    isPlaying={currentPlayingId === msg.id}
                    onPlay={handlePlayAudio}
                    onPause={stopCurrentAudio}
                />
            ))}
            {isThinking && <ThinkingBubble />}
            <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className={`p-4 border-t ${isDarkMode ? 'bg-kandu-900 border-kandu-800' : 'bg-white border-kandu-200'}`}>
         <div className="max-w-3xl mx-auto flex items-end gap-2 md:gap-4">
            
            {/* Attach Button */}
            <button 
                onClick={() => fileInputRef.current?.click()}
                className={`p-3 rounded-full mb-1 transition-all ${isDarkMode ? 'bg-zinc-800 text-zinc-400 hover:text-zinc-200' : 'bg-zinc-100 text-zinc-500 hover:text-zinc-700'}`}
            >
                <ImageIcon size={20} />
            </button>
            <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*,video/*"
                onChange={handleFileUpload}
            />

            {/* Text Input */}
            <div className={`flex-1 rounded-2xl border transition-all ${isDarkMode ? 'bg-kandu-950 border-kandu-700 focus-within:border-zinc-500' : 'bg-kandu-50 border-kandu-300 focus-within:border-zinc-400'}`}>
                <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                        if(e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                        }
                    }}
                    placeholder="Kirim pesan..."
                    rows={1}
                    className={`w-full bg-transparent px-4 py-3 focus:outline-none resize-none max-h-32 ${isDarkMode ? 'text-zinc-200 placeholder-zinc-600' : 'text-zinc-800 placeholder-zinc-400'}`}
                    style={{ minHeight: '48px' }}
                />
            </div>

            {/* Mic / Send Button */}
            {inputText.trim() ? (
                 <button 
                    onClick={handleSendMessage}
                    className={`p-3 rounded-full mb-1 transition-transform hover:scale-105 active:scale-95 ${isDarkMode ? 'bg-zinc-200 text-kandu-950' : 'bg-zinc-800 text-white'}`}
                 >
                    <Send size={20} />
                 </button>
            ) : (
                <button 
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    onMouseLeave={stopRecording}
                    onTouchStart={startRecording}
                    onTouchEnd={stopRecording}
                    className={`p-3 rounded-full mb-1 transition-all select-none ${
                        isRecording 
                        ? 'bg-red-500 text-white scale-110 animate-pulse ring-4 ring-red-500/30' 
                        : isDarkMode ? 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700' : 'bg-zinc-200 text-zinc-600 hover:bg-zinc-300'
                    }`}
                >
                    <Mic size={20} />
                </button>
            )}
         </div>
         {isRecording && (
             <div className="text-center text-xs text-red-500 mt-2 font-medium animate-pulse">
                 Merekam... Lepas untuk mengirim
             </div>
         )}
      </footer>
    </div>
  );
}