import { GoogleGenAI, Modality } from "@google/genai";
import { SYSTEM_INSTRUCTION, MODEL_TEXT, MODEL_TTS } from "../constants";

// Helper to get API key safely
const getApiKey = (): string => {
    // In this specific sandbox environment, we use process.env.API_KEY
    return process.env.API_KEY || '';
};

// Initialize GenAI
const createAI = () => new GoogleGenAI({ apiKey: getApiKey() });

export const sendMessageToGemini = async (
    history: { role: string; parts: { text: string }[] }[],
    newMessage: string,
    imageBase64?: string,
    mimeType: string = 'image/jpeg'
): Promise<string> => {
    const ai = createAI();
    
    // Using generateContent with system instruction
    // We construct the prompt manually because we might mix text and images
    
    const parts: any[] = [{ text: newMessage }];
    
    if (imageBase64) {
        parts.unshift({
            inlineData: {
                mimeType: mimeType,
                data: imageBase64
            }
        });
    }

    try {
        // Fix: Include history in the contents array so Gemini remembers the conversation.
        const contents = [
            ...history,
            {
                role: 'user',
                parts: parts
            }
        ];

        const response = await ai.models.generateContent({
            model: MODEL_TEXT,
            contents: contents,
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
            }
        });
        
        return response.text || "Maaf, saya tidak dapat memproses itu.";
    } catch (error) {
        console.error("Gemini API Error:", error);
        return "Terjadi kesalahan pada jaringan neural saya.";
    }
};

export const generateSpeech = async (text: string): Promise<string | null> => {
    const ai = createAI();
    
    try {
        const response = await ai.models.generateContent({
            model: MODEL_TTS,
            contents: {
                parts: [{ text: text }]
            },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Puck' } // 'Puck' is a standard male voice
                    }
                }
            }
        });

        const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return audioData || null;
    } catch (error) {
        console.error("TTS Error:", error);
        return null;
    }
};