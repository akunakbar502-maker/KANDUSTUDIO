export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove data URL prefix (e.g., "data:audio/wav;base64,")
      const base64Data = base64String.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Decodes and plays raw PCM 16-bit audio from Gemini TTS
 * Returns a control object with a stop function.
 */
export const playPCMAudio = (base64String: string, sampleRate = 24000, onEnded?: () => void) => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const audioContext = new AudioContextClass({ sampleRate });

    // 1. Decode Base64 to binary string
    const binaryString = atob(base64String);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // 2. Convert 8-bit bytes to 16-bit integers (PCM)
    const dataInt16 = new Int16Array(bytes.buffer);

    // 3. Create Audio Buffer
    const buffer = audioContext.createBuffer(1, dataInt16.length, sampleRate);
    const channelData = buffer.getChannelData(0);

    // 4. Convert Int16 to Float32 (-1.0 to 1.0)
    for (let i = 0; i < dataInt16.length; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }

    // 5. Play
    const source = audioContext.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContext.destination);
    
    source.onended = () => {
        if (onEnded) onEnded();
        audioContext.close();
    };

    source.start();

    return {
        stop: () => {
            try {
                source.stop();
                audioContext.close();
            } catch (e) {
                // Ignore if already stopped
            }
        }
    };

  } catch (error) {
    console.error("Error playing PCM audio:", error);
    if (onEnded) onEnded();
    return { stop: () => {} };
  }
};