export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface Message {
  id: string;
  role: Role;
  text: string; // Still needed for the TTS generation source, but can be hidden in UI
  timestamp: number;
  audioUrl?: string; // If the message is a voice note
  imageUrl?: string; // If the message has an image
  isVoiceResponse?: boolean; // If true, it contains AI generated audio
  isVoiceOnly?: boolean; // If true, hide the text bubble (for voice-to-voice feel)
}

export interface UserProfile {
  username: string;
  isLoggedIn: boolean;
}

export interface AudioState {
  isRecording: boolean;
  audioBlob: Blob | null;
  base64Audio: string | null;
}